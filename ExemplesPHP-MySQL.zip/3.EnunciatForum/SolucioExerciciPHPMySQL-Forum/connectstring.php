<?php
$pdo= new PDO("mysql:host=localhost;dbname=forum","root","1234");
?>

