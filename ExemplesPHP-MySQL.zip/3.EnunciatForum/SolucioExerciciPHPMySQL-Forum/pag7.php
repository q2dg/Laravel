<?php
	session_start();
?>
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
	<?php
	if (isset($_SESSION['nomusuari']) == true ) { echo ("Benvingut <b>". $_SESSION['nomusuari'] ."</b><br><br>"); }
	if (isset($_SESSION['entrada']) == true ) { echo ("Està afegint un missatge a l'entrada <b>". $_SESSION['entrada'] ."</b><br><br>"); }
	?>
	<form action="processentrada2.php" method="post">
		Texte:<br><textarea name="texte" required="true"></textarea><br><br>
		<button type="submit">Aceptar</button>
	</form>
	<form action="pag3.php"><button type="submit">Cancelar</button></form>
</body>
</html>
