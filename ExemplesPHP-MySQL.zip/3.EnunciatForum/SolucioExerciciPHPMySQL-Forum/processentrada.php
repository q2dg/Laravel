<?php
session_start();
include("connectstring.php");

//Augmento en 1 el número de comentaris fets per l'usuari actual. Per això primer he d'obtenir el nº de comentaris fets fins ara i després sumar 1 
$stmt=$pdo->prepare("select NUMCOMENTARIS from USUARIS where CODIU = ? ;");
$stmt->execute(array($_SESSION['codiusuari']));
$numcomentaris=$stmt->fetchColumn(0);
$numcomentaris=$numcomentaris + 1;
$stmt=null;
$stmt=$pdo->prepare("update USUARIS set NUMCOMENTARIS = ? where CODIU = ? ;");
$stmt->execute(array($numcomentaris,$_SESSION['codiusuari']));
$stmt=null;

//Com que és el primer missatge d'una nova entrada, he de fer dos inserts, un a la taula "Entrades" i un altre a la taula "Missatges". 
$stmt = $pdo->prepare("insert into ENTRADES values (null,:paramtitol,:paramsala,:paramcodiu,:paramnumresp,:paramdataentrada);");
$stmt->bindParam(':paramtitol', $_POST['titol']);
$stmt->bindParam(':paramsala', $_SESSION['sala']);
$stmt->bindParam(':paramcodiu', $_SESSION['codiusuari']);
$stmt->bindValue(':paramnumresp', 0); //Com que és el primer missatge de l'entrada, el seu valor concret el conec (0).
date_default_timezone_set("Europe/Madrid");  //Aquest línia és per evitar un warning en executar la funció date() i/o time().
$avui = date("Y-m-d H:i:s", time());
$stmt->bindParam(':paramdataentrada', $avui);
if($stmt->execute() == false) { die ("No s'ha pogut realitzar la inserció de l'entrada ".$stmt->errorInfo()); }
$codie=$pdo->lastInsertId();  //He de saber el codi de l'entrada acabada de crear per realitzar l'insert següent
$stmt=null;

$stmt=$pdo->prepare("insert into MISSATGES values (null,:paramtexte,:paramcodiu,:paramcodie,:paramdatamissatge);");
$stmt->bindParam(':paramtexte', $_POST['texte']);
$stmt->bindParam(':paramcodiu', $_SESSION['codiusuari']); 
$stmt->bindParam(':paramcodie', print_r($codie)); //print_r és necessari per alguna raó !!?
$stmt->bindParam(':paramdatamissatge', $avui); 
if($stmt->execute() == false) { die ("No s'ha pogut realitzar la inserció del primer missatge de l'entrada ".$stmt->errorInfo()); }
$stmt=null;
$pdo=null;

header("Location:pag2.php?sala=".$_SESSION['sala']);

?>

