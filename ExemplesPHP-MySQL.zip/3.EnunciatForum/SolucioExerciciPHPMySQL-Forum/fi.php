<?php
//Destrueixo la possible sessió prèviament oberta
session_start();
session_unset();
session_destroy();
?>
<html>
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<p>Gràcies per la seva visita</p>
		<a href="pag1.php">Inici<a>
	</body>
</html>
