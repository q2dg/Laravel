<html>
<head><meta charset="utf-8"></head>
<body>
<?php
$nombd=$_GET['nombd'];
//Conexió al servidor
$conexio = mysqli_connect("localhost","root",1234);
if ($conexio == false){	die("No s'ha pogut conectar amb el servidor: " . mysqli_connect_error()); }
//Creació de la base de dades i tancament de la conexió
if(mysqli_query($conexio, "create database ".$nombd.";") == true){
	mysqli_close($conexio); 
	echo "Base de dades ". $nombd ." creada amb <span style='color:green;font-weight:bold;'>ÈXIT</span>.<br><br>";
} else {
	echo "No s'ha pogut crear la base de dades.<br>". mysqli_error($conexio);
	mysqli_close($conexio); 
	exit();
}	

//Conexió a la base de dades del servidor recentment creada
$conexio = mysqli_connect("localhost","root",1234,$nombd);
if ($conexio == false){	die("No s'ha pogut conectar amb la base de dades: " . mysqli_connect_error()); }
//Creació taula USUARIS
$sql="CREATE TABLE USUARIS 
      (CODIU INT NOT NULL AUTO_INCREMENT, 
       NOMU VARCHAR(20) NOT NULL,
       CONTRASENYA VARCHAR(20) NOT NULL,
       NUMCOMENTARIS INT NOT NULL DEFAULT 0,
       PRIMARY KEY(CODIU));";
if (mysqli_query ($conexio,$sql) == true){
	echo ("Taula <span style='color:green;'>USUARIS</span> creada.<br>"); 
} else {
	mysqli_close($conexio); 
	die ("Creació taula <span style='color:red;'>USUARIS</span> no vàlida");
} 
//Creació taula SALES
$sql="CREATE TABLE SALES 
      (CODIS INT NOT NULL AUTO_INCREMENT ,
       TITOLS VARCHAR(50) NOT NULL,
       MINIMCOMENTARIS INT NOT NULL DEFAULT 0,
       PRIMARY KEY(CODIS));";
if (mysqli_query ($conexio,$sql) == true){
	echo "Taula <span style='color:green;'>SALES</span> creada.<br>"; 
} else {
	mysqli_close($conexio); 
	die ("Creació taula <span style='color:red;'>SALES</span> no vàlida");
}
//Creació taula ENTRADES
$sql="CREATE TABLE ENTRADES
      (CODIE INT NOT NULL AUTO_INCREMENT,
       TITOLE VARCHAR(50) NOT NULL,
       CODIS INT NOT NULL, 
       CODIU INT NOT NULL,
       NUMRESP INT NOT NULL,
       DATAENTRADA DATETIME NOT NULL,
       PRIMARY KEY(CODIE),	
       FOREIGN KEY(CODIS) REFERENCES SALES(CODIS) ON DELETE CASCADE ON UPDATE CASCADE,
       FOREIGN KEY(CODIU) REFERENCES USUARIS(CODIU) ON DELETE CASCADE ON UPDATE CASCADE);";
if (mysqli_query ($conexio,$sql) == true){
	echo "Taula <span style='color:green;'>ENTRADES</span> creada.<br>"; 
} else {
	mysqli_close($conexio); 
	die ("Creació taula <span style='color:red;'>ENTRADES</span> no vàlida");
}
//Creació taula MISSATGES
$sql="CREATE TABLE MISSATGES
      (CODIM INT NOT NULL AUTO_INCREMENT,
       TEXTE VARCHAR(250) NOT NULL,
       CODIE INT NOT NULL, 
       CODIU INT NOT NULL,
       DATAMISSATGE DATETIME NOT NULL,
       PRIMARY KEY(CODIM),	
       FOREIGN KEY(CODIE) REFERENCES ENTRADES(CODIE) ON DELETE CASCADE ON UPDATE CASCADE,
       FOREIGN KEY(CODIU) REFERENCES USUARIS(CODIU) ON DELETE CASCADE ON UPDATE CASCADE);";
if (mysqli_query ($conexio,$sql) == true){
	echo "Taula <span style='color:green;'>MISSATGES</span> creada.<br>"; 
} else {
	mysqli_close($conexio); 
	die ("Creació taula <span style='color:red;'>MISSATGES</span> no vàlida");
}
//Missatge informatiu (final de creació de taules correcta)
echo "Creació de totes les taules finalitzada amb <span style='color:green;font-weight:bold;'>ÈXIT</span>.<br><br>";
//Comencem les insercions d'usuaris... 		 	 		 	 		 
$sql="INSERT INTO USUARIS VALUES
      (null, 'pepe', 'asdf', default),
      (null, 'paco', 'qwer', default),
      (null, 'mary', 'zxcv', default),
      (null, 'lola', '7890', default);";
if (mysqli_query ($conexio,$sql) == true){
	echo "Inserció correcta d'<span style='color:green;'>USUARIS</span>.<br>"; 
} else {
	mysqli_close($conexio); 
	die ("Inserció incorrecta d'<span style='color:red;'>USUARIS</span>.<br>"); 
}
//...i de sales
$sql="INSERT INTO SALES VALUES
      (null, 'Cotxes', default),
      (null, 'Ordinadors', default),
      (null, 'Viatges', default),
      (null, 'Llibres, musica i cine', default),
      (null, 'Cuina', default);";
if (mysqli_query ($conexio,$sql) == true){
	echo "Inserció correcta de <span style='color:green;'>SALES </span>.<br>"; 
} else {
	mysqli_close($conexio); 
	die ("Inserció incorrecta de <span style='color:red;'>SALES</span>.<br>"); 
}
//Missatge informatiu (final d'insercions correctes)
echo "Procés d'inserció de dades finalitzat amb <span style='color:green;font-weight:bold;'>ÈXIT</span>.<br>";
mysqli_close($conexio);	 
?>
</body>
</html>
