<?php
session_start();
/*Comprovo si la sessió ja està oberta d'abans amb el procediment correcte (per evitar que s'escrigui la URL d'aquesta pàgina directament
a la barra del navegador, per exemple). Si no, redirecciono a la pàgina inicial */
if (isset($_SESSION['nomusuari']) == false ) { header("Location:pag1.php"); }
?>
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
<?php
//Si ja estic loguejat mostro un missatge de benvinguda. Si no, no
if (isset($_SESSION['nomusuari']) == true ) { echo ("Benvingut <b>". $_SESSION['nomusuari'] ."</b><br><br>"); }
?>
	<form action="processentrada.php" method="post">
		<table>
		<tr><td>Títol d'entrada:</td><td><input type="text" name="titol" required="true"></td></tr>
		<tr><td>Texte:</td><td><textarea name="texte" required="true"></textarea></td></tr></table>
		<button type="submit">Aceptar</button>
	</form>
	<!-- A pag4.php vam optar per tenir dos botons dins d'un mateix formulari. Aquí en canvi, fem un formulari diferent per cada botó -->
	<form action="pag2.php">
	<?php 
		echo "<input type='hidden' name='sala' value='". $_SESSION['sala'] ."'>"; 
	?>
	<button type="submit" >Tornar a la sala</button></form>
</body>
</html>
