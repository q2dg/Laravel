<?php
session_start();
$texte=$_POST['texte'];
/*Si un visitant clica en el botó de "nova resposta" sense haver-se loguejat primer, sortirà el següent missatge d'error.
Una alternativa hauria sigut deshabilitar aquest botó (com s'ha fet amb el de "nova entrada") */
if (isset($_SESSION['codiusuari']) == false) { die ("No s'has loguejat. Vés <a href='pag4.php'>aquí </a> per fer-ho."); }
//Comprovar que no s'ha deixar cap caixa sense emplenar (això amb l'atribut HTML5 required=true ja no cal
//if (empty($codiu) ==true || empty($texte)==true) { header("Location:pag7.php"); }

include("connectstring.php");

//Obtinc el número actual de comentaris que té l'usuari de la sessió...
$stmt=$pdo->prepare("select NUMCOMENTARIS from USUARIS where CODIU = ? ;");
if($stmt->execute(array($_SESSION['codiu'])) == false) { die("No s'ha pogut realitzar la consulta 1". $stmt->errorInfo()); }
$numcom=$stmt->fetchColumn(0);
//...per augmentar-li en 1
$numcom=$numcom +1;
$stmt=null;
$stmt=$pdo->prepare("update USUARIS set NUMCOMENTARIS = ? where CODIU= ? ;");
if($stmt->execute(array($numcom,$_SESSION['codiu'])) == false) { die("No s'ha pogut realitzar la modificació 1". $stmt->errorInfo()); }
$stmt=null;

//Modifico el número de respostes de l'entrada en qüestió
$stmt=$pdo->prepare("select NUMRESP from ENTRADES where CODIE = ? ;");
if($stmt->execute(array($_SESSION['entrada'])) == false) { die("No s'ha pogut realitzar la consulta 2". $stmt->errorInfo()); }
$numresp=$stmt->fetchColumn(0);
$numresp=$numresp+1;
$stmt = $pdo->prepare("update ENTRADES set NUMRESP = ? where CODIE=? ;");
if($stmt->execute(array($numresp,$_SESSION['entrada'])) == false) { die("No s'ha pogut realitzar la modificació 2". $stmt->errorInfo()); }
$stmt=null;

//I faig, finalment, la inserció del missatge 
date_default_timezone_set("Europe/Madrid");
$stmt=$pdo->prepare("insert into MISSATGES values (null,:paramtexte,:paramcodie,:paramcodiu,:paramdatamissatge);");
$stmt->bindParam(':paramtexte', $texte);
$stmt->bindParam(':paramcodie', $_SESSION['entrada']);
$stmt->bindParam(':paramcodiu', $_SESSION['codiusuari']); 
$stmt->bindValue(':paramdatamissatge', date("Y-m-d H:i:s", time())); 
if($stmt->execute() == false) { die("No s'ha pogut realitzar la inserció". $stmt->errorInfo()); }
$stmt=null;

header("Location:pag3.php");

$pdo=null;
?>
