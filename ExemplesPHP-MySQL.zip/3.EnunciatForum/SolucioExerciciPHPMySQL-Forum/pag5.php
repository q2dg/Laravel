<?php
	//Destrueixo la possible sessió prèviament oberta
	session_start();
	session_unset();
	session_destroy();
?>
<html>
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<p>Usuari inexistent o contrasenya incorrecta</p>
		<a href="pag4.php">Tornar</a>
	</body>
</html>
