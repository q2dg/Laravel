<?php
session_start();
/*Si vinc de Pag2, creo la variable de sessió Entrada. Si vinc d'un altre lloc (Pag7), no cal perquè aquesta variable ja haurà estat creada abans */
if (isset($_GET['entrada'])== true) { $_SESSION['entrada']=$_GET['entrada'];}
?>
<html>
<head>
	<meta charset="UTF-8">
	<style type="text/css">
		th { background-color: #000000; color: white; }
		table,td { border: 1px solid black; } 
		.enlacenegro { color: black; }
	</style>
</head>
<body>
<?php
include("connectstring.php");
$stmt=$pdo->prepare("select TEXTE,CODIU,DATAMISSATGE from MISSATGES where CODIE=? order by 3 desc;");
$stmt->execute(array($_SESSION['entrada']));
//Si ja estic loguejat mostro un missatge de benvinguda. Si no, no
if (isset($_SESSION['nomusuari']) == true ) { echo ("Benvingut <b>". $_SESSION['nomusuari'] ."</b><br><br>"); }
//Mostro el llistat de missatges per aquesta entrada
echo "<table><tr><th>Texte Entrada</th><th>Codi d'usuari</th><th>Data publicació</th></tr>";
while($row=$stmt->fetch(PDO::FETCH_NUM)){
	echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td></tr>";
}
echo "</table>";
$stmt=null;
$pdo=null;
?>
<form action="pag7.php"><button type="submit">Respondre</button></form>
<form action="pag2.php">
	<!--El camp hidden és necessari per passar un paràmetre via GET a pag2.php quan es premi el botó "submit" perquè
	l'atribut action no admet la sintaxi pag2.php?clau=valor&clau=valor...       -->
	<?php 
		echo "<input type='hidden' name='sala' value='". $_SESSION['sala'] ."'>"; 
	?>
	<button type="submit">Tornar a la sala</button></form>
</body></html>
