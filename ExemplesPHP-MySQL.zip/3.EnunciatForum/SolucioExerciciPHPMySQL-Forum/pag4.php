<?php 
	//Aquí és on hauria de començar la sessió
	session_start();
?>
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
	<form action="processusuari.php" method="post">
		<table><tr><td> Usuari: </td><td><input type="text" name="usuari" required="true"> </td></tr>
		<tr><td> Contrasenya: </td><td> <input type="password" name="contra" required="true"> </td></tr></table>
		<button type="submit" name="boto" value="aceptar">Aceptar</button>
		<!-- L'atribut formnovalidate és per a què es pugui pulsar al botó Cancelar encara que les caixes (required) estiguin buides -->
		<button type="submit" name="boto" value="cancelar" formnovalidate="true">Cancelar</button>
	</form>
</body>
</html>
