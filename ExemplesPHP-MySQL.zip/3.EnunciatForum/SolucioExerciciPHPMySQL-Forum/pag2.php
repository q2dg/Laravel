<?php
	session_start();
	//Comprovo si hi ha seleccionada una sala (podria ser que no si no vinc de pag1.php)
	if (isset($_GET['sala'])==true) {  
		$_SESSION['sala']=$_GET['sala']; 
	} else {
		die("No hi ha cap sala seleccionada");
	}
?>
<html>
<head>
	<meta charset="UTF-8">
	<style type="text/css">
		th { background-color: #000000; color: white; }
		table,td { border: 1px solid black; } 
		.enlacenegro { color: black; }
	</style>
</head>
<body>
<?php
include("connectstring.php");
/*Només he d'obtenir les entrades de la sala seleccionada. En realitat, la consulta hauria de ser més complicada per obtenir
els noms dels usuaris en comptes dels codis, però ho deixarem còrrer */
$stmt=$pdo->prepare("select * from ENTRADES where CODIS=?"); 
$stmt->execute(array($_SESSION['sala']));
//Si ja estic loguejat mostro un missatge de benvinguda. Si no, no
if (isset($_SESSION['nomusuari']) == true ) { echo ("Benvingut <b>". $_SESSION['nomusuari'] ."</b> a la sala <b>".  $_SESSION['sala'] ."</b><br><br>"); }
//Mostro les entrades de la sala
echo "<table><tr><th>Títol Entrada</th><th>Codi d'usuari</th><th>Nº respostes</th><th>Data publicació</th></tr>";
while($row=$stmt->fetch(PDO::FETCH_NUM)){
	/*L'enllaç incorpora l'identificador de l'entrada, però el que es mostra és el seu títol, el codi d'usuari, nº de resp i data publ.
	Una possible millora seria que l'enllaç incorporés el títol de l'entrada associat a l'identificador, però ho deixarem còrrer */
	echo "<tr><td><a href='pag3.php?entrada=" .$row[0] . "'>$row[1]</a></td>
	      <td>$row[3]</td><td>$row[4]</td><td>$row[5]</td></tr>";
}
echo "</table>";
$stmt=null;
$pdo=null;
//Si estic loguejat, el botó "Nou" està activat, però si no, no
if(isset($_SESSION['nomusuari']) == true) {
	echo "<br><form action='pag6.php'><button type='submit'>Nou</button></form>";
} else {
	echo "<br><form action='pag6.php'><button type='submit' disabled='true'>Nou</button></form>";
}
?>
<form action="pag1.php"><button type="submit">Inici</button></form>
</body></html>
