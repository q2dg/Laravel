<?php
session_start(); //Continuo la sessi� comen�ada (en teoria) a pag4.php
$usuari=$_POST['usuari'];
$contra=$_POST['contra'];
$boto=$_POST['boto'];
if($boto == "cancelar") {
	//Destrueixo la sessi� que pugui existir...
	if(isset($_SESSION['nomusuari']) ==true) { session_unset(); session_destroy(); }
	header("Location:pag1.php");
} else if($boto == "aceptar") {
	include("connectstring.php");
	//Comprovo el login...
	$stmt=$pdo->prepare("select CODIU,NOMU from USUARIS where NOMU = :paramusuari and CONTRASENYA like :paramcontrasenya");
	/*En comptes de la l�nia seg�ent podr�em haver escrit aquestes tres l�nies (�s el mateix): 
	$stmt->bindParam(':paramusuari', $usuari); 
	$stmt->bindParam(':paramcontrasenya', $contra);
	$stmt->execute(); */
	$stmt->execute(array(':paramusuari' => $usuari, ':paramcontrasenya' => $contra));
	$row=$stmt->fetch(PDO::FETCH_NUM);
	//Si no obtinc res de la consulta anterior, vol dir que l'usuari o contrasenya no s�n correctes (no es troben a la base de dades)
	if (empty($row)==true) { 
		header("Location:pag5.php"); 
	} else { 
		//Si s� s�n correctes, agafo el codi i el nom d'usuari i els converteixo en variables de sessi�
		$_SESSION['codiusuari']=$row[0];
		$_SESSION['nomusuari']=$row[1];
		header("Location:pag1.php"); 
	} 
	$stmt=null;
	$pdo=null;
}
?>
