<?php 
//Més que iniciar una sessió, continuo la sessió iniciada (en principi) a pag4.php
session_start(); 
?>
<html>
<head>
	<meta charset="utf-8">
	<!--El CSS també es podria escriure en un fitxer apart i fer-hi referència des d'aquí amb la línia:
	<link rel="stylesheet" type=text/css" href="/ruta/fitxer.css"> -->
	<style type="text/css">
		th { background-color: #000000; color: white; }
		table,td { border: 1px solid black; }
		.enlacenegro { color: black; }
	</style>
</head>
<body>
	<?php
	$pdo= new PDO("mysql:host=localhost;dbname=forum","root","1234");
	$res=$pdo->query("select CODIS,TITOLS from SALES;");
	if ($res==false) { die("Ha hagut un error a la consulta"); }
	//Si ja estic loguejat mostro un missatge de benvinguda. Si no, no
	if (isset($_SESSION['nomusuari']) == true ) { echo ("Benvingut <b>". $_SESSION['nomusuari'] ."</b><br><br>"); }
	//Mostro les sales que hi ha a la base de dades, per a què el visitant pugui entrar-hi en la que desitji
	echo "<table><tr><th>Sales</th></tr>";
	while($row=$res->fetch(PDO::FETCH_NUM)){ //També es pot fer servir el paràmetre PDO::FETCH_ASSOC o PDO::FETCH_BOTH (per defecte)
		echo "<tr><td><a class='enlacenegro' href='pag2.php?sala=$row[0]'>$row[1]</a></td></tr>";
	}
	$res=null;
	$pdo=null;
	?>
	</table><br>
	<a href="pag4.php">Login</a>
	<a href="fi.php">Sortir</a>
</body>
</html>
