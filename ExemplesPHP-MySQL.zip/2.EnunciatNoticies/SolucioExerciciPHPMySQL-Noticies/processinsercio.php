<?php
session_start();
$textenot=$_POST['textenot'];

include("./connection.php");

//Trobo el codi d'usuari de l'usuari que vol insertar la notícia
$stmt=$pdo->prepare("select codiusu from Usuaris where nomusu like ?");
$stmt->execute(array($_SESSION['nomusu']));
//Les dues següents línies serien equivalents a fer simplement: $codiusu=$stmt->fetchColum(0);
$row=$stmt->fetch(PDO::FETCH_NUM);
$codiusu=$row[0];
$stmt=null;
//Insereixo la notícia.Primer defineixo la sentència...(en aquest cas, es fan servir paràmetres amb nom en comptes de '?')
$stmt=$pdo->prepare("insert into Noticies values (null,:paramtextenot,:paramdatanot,:paramcodiusu)");
$stmt->bindParam(':paramtextenot', $paramtextenot); //Associo cada paràmetre a una variable...
$stmt->bindParam(':paramdatanot', $paramdatanot);
$stmt->bindParam(':paramcodiusu', $paramcodiusu);
//...asigno els valors a aquestes variables...
$paramtextenot=$textenot;
$paramdatanot = date("Y-m-d/H:i:s", time());
$paramcodiusu=$codiusu;
//...i executo la sentència
if ($stmt->execute() == false) {
	die ("<!DOCTYPE html><html><body>No s'ha pogut realitzar la inserció</body></html>");
}
$stmt=null;
$pdo=null;
//Un cop executada, redirecciono de nou a pàgina 3 (si és usuari 'admin') o 2 (si no ho és)
if ($_SESSION['codiusu'] == $_SESSION['codiusuadmin']) {
	header("Location:pag3.php");
} else {
	header("Location:pag2.php");
}

?>

