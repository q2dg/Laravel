<?php
session_start();
$_SESSION['nomusu']=$_POST['nomusu'];
$contra=$_POST['contra'];

if (empty($_SESSION['nomusu']) == true || empty($contra) == true) {
	header("Location:pag4.php?avis=1");
	exit();
}

include("./connection.php");

//Obtinc el codi de l'usuari que té guardats a la BD el mateix nom i contrasenya que els introduïts al formulari inicial
$stmt=$pdo->prepare("select codiusu from Usuaris where nomusu like ? and contrasenya like ?");
$stmt->execute(array($_SESSION['nomusu'], $contra)); //Substitueixo els valors dels interrogants pels elements de l'array indicat
$codiusu=$stmt->fetchColumn(0); //Cada vegada que s'executés fetchColumn(0), retornaria el valor de 1r camp (1r degut al '0') de la següent fila.
$stmt=null; //Com que no faré servir més l'objecte $stmt, el destrueixo
//Si no hi ha cap usuari+contrasenya que coincideixi (és a dir, si la consulta anterior no retorna res), mostro un missatge d'error i ja està.
if (empty($codiusu)== true) {
	header("Location:pag4.php?avis=2");
	exit();
} else { //Si sí, guardo el codi d'usuari en una altra variable de sessió (ja que m'interessarà per més endavant) a més de la corresponent al seu nom
	$_SESSION['codiusu']=$codiusu;
}

//D'altra banda, trobo el codi d'usuari de l'usuari 'admin', per veure si és el mateix que el codi corresponent a l'introduït per l'usuari ($codiusu)
$res=$pdo->query("select codiusu from Usuaris where nomusu='admin'");
$codiusuadmin=$res->fetchColumn(0);
$res=null;
$pdo=null;
$_SESSION['codiusuadmin']=$codiusuadmin; //M'interessarà guardar també el codi d''admin' en una variable de sessió (per més endavant).

//Si l'usuari introduït és el 'admin'...
if ($codiusu == $codiusuadmin) {
	header("Location:pag3.php");
//Si l'usuari introduït és un altre
} else {
	header("Location:pag2.php");
}

?>
