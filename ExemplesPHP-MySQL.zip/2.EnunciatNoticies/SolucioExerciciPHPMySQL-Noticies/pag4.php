<?php
session_start();
session_destroy();
$avis=$_GET['avis'];
if ($avis == 1) {
	echo("T'has deixat per escriure alguna caixa.");
} elseif ($avis == 2) {
	echo("Usuari inexistent o contrasenya incorrecta.");
} else {
	echo "Error.";
}
echo("Clica <a href='pag1.html'>aquí </a>per tornar al començament");
?>

