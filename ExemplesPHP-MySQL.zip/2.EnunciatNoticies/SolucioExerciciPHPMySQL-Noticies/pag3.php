<?php
session_start();

/*Comprovo que el visitant arribi a aquesta pàgina fent servir un usuari registrat, i a més, que aquest usuari sigui "admin". Si no fos així (cosa que pot passar si s'escriu directament la Url de pag3.php a la barra del navegador sense haver-se loguejat primer com a "admin", per exemple), redirecciono el visitant a la pàgina inicial */
if(empty($_SESSION['codiusu']) == true || $_SESSION['codiusu']!= $_SESSION['codiusuadmin']){ 
	header("Location:pag1.html");
	exit();
} else {
	include("./connection.php");
	$res=$pdo->query("select codinot,codiusu,datanot,textenot from Noticies order by 3 desc");
	echo "<!DOCTYPE html><html><body><table border='1'>"; //L'atribut 'border' està anticuat però s'ha escrit aquí per conveniència
	while($row=$res->fetch(PDO::FETCH_NUM)){              //Veure http://php.net/manual/en/pdostatement.fetch.php
		echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
	}
	echo "</table>";
	$res=null;
	$pdo=null;
}
?>

<form action="pag5.php"><button type="submit">Nova notícia</button></form>

<form action="pag6.php"><button type="submit">Modificar notícia</button></form>

<form action="pag7.php"><button type="submit">Esborrar notícia</button></form>

<form action="logout.php"><button type="submit">Sortir</button></form>

</body>
</html>
