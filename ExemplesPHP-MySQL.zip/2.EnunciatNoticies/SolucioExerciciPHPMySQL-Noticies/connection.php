<?php
$pdo= new PDO("mysql:host=localhost;dbname=Noticies","root","1234");
?>
