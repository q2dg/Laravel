<?php
session_start();
$codinot=$_POST['codinot'];
//Comprovo si el codi de notícia introduït és un número. Si no ho és, torno a demanar-ho. Veure http://php.net/manual/en/function.preg-match.php
if (preg_match("/^[0-9]+$/", $codinot) == false){
	header("Location:pag6.php");
	exit();
}

include("./connection.php");

$stmt=$pdo->prepare("select * from Noticies where codinot = ?");
$stmt->execute(array($codinot));
$row=$stmt->fetch(PDO::FETCH_NUM);
$stmt=null;
$pdo=null;
//Si no es troba la noticia, es torna a demanar
if(empty($row) == true ) {
	header("Location:pag6.php");
	exit();
}
//Si sí, es mostren tots els camps de la taula Noticies amb la possibilitat de canviar el valor de $row[1] (camp corresponent a la columna 'textenot')
echo "<!DOCTYPE html><html><body>";
echo "Codi notícia:$row[0]<br/>"; //El seu valor hauria de ser igual a $codinot
echo "Data notícia:$row[2]<br/>";
echo "Codi d'usuari:$row[3]<br/>";
echo "<form action='processmodificacio.php' method='post'>";
echo "<input type='hidden' name='codinot' value='".$codinot."'>"; //Una altra manera de passar paràmetres (via POST); cal fer-ho x identificar notícia
echo "<textarea name='textenot'>$row[1]</textarea><br>";
echo "<button type='submit'>Enviar</button>";
echo "</form></body></html>";

?>

