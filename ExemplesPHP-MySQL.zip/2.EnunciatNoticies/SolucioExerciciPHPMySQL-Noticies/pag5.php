<?php session_start(); ?>
<!DOCTYPE html>
<html>
<body>
	<form action="processinsercio.php" method="post">
		<textarea name="textenot"></textarea><br>
		<button type="submit">Enviar</button>
	</form>
</body>
</html>
