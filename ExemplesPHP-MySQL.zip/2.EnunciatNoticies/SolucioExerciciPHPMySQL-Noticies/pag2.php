<?php
session_start();

/*Comprovo que el visitant arribi a aquesta pàgina fent servir un usuari registrat. Si no fos així (cosa que pot passar si s'escriu directament la Url de pag2.php a la barra del navegador sense haver-se loguejat primer, per exemple), redirecciono el visitant a la pàgina inicial. Aquesta comprovació, de fet, caldria fer-la a totes les pàgines. */
if(empty($_SESSION['codiusu']) == true){
	header("Location:pag1.html");
	exit();
} else {
	include("./connection.php");
	$res=$pdo->query("select codinot,codiusu,datanot,textenot from Noticies order by 3 desc");
	echo "<!DOCTYPE html><html><body><table border='1'>";
	while($row=$res->fetch(PDO::FETCH_NUM)){
		echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
	}
	echo "</table>";
	$res=null;
	$pdo=null;
}
?>

<form action="pag5.php"><button type="submit">Nova notícia</button></form>

<form action="logout.php"><button type="submit">Sortir</button></form>

</body>
</html>
