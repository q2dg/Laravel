<?php
session_start();
$codinot=$_POST['codinot'];
$textenot=$_POST['textenot'];

include("./connection.php");

$stmt=$pdo->prepare("update Noticies set textenot = ? where codinot = ?");
if ($stmt->execute(array($textenot,$codinot)) == false) {
	die ("<!DOCTYPE html><html><body>No s'ha pogut realitzar la modificació</body></html>");
} else {
	header("Location:pag3.php");
}

$stmt=null;
$pdo=null;

?>

