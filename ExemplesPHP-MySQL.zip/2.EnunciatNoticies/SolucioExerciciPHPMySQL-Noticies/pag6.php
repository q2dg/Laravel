<?php 
session_start(); 
/* Una possible millora en aquesta pàgina seria substituir la caixa de texte per un combo on apareguessin els codis de notícies actualment existents llestes per seleccionar */
?>
<!DOCTYPE html>
<html>
<body>
	<form action="pag8.php" method="post">
		Codi de la noticia:<input type="text" name="codinot">
		<button type="submit">Enviar</button>
	</form>
</body>
</html>
