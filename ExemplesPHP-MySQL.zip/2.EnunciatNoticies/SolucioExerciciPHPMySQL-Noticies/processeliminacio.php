<?php
session_start();
$codinot=$_POST['codinot'];
//Comprovo si el codi de notícia introduït és un número. Si no ho és, torno a demanar-ho. Veure http://php.net/manual/en/function.preg-match.php
if (preg_match("/^[0-9]+$/", $codinot) == false){
	header("Location:pag7.php");
	exit();
}

include("./connection.php");

$stmt=$pdo->prepare("delete from Noticies where codinot = ?");
if ($stmt->execute(array($codinot)) == FALSE) {
	die ("<!DOCTYPE html><html><body>No s'ha pogut realitzar l'eliminació</body></html>");
} else {
	header("Location:pag3.php");
}

$stmt=null;
$pdo=null;

?>

