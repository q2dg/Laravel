CREATE TABLE Usuaris (
codiusu smallint unsigned auto_increment,
nomusu varchar(255) not null,
contrasenya varchar(255) not null,
constraint usuarisPK primary key(codiusu)
);

CREATE TABLE Noticies (
codinot smallint unsigned auto_increment,
textenot varchar(255) not null,
datanot datetime,
codiusu smallint unsigned,
constraint noticiesPK primary key(codinot),
constraint noticiesFK foreign key(codiusu) references Usuaris(codiusu)
);

INSERT INTO Usuaris VALUES (null,'admin','admin');
INSERT INTO Usuaris VALUES (null,'pepe','1234');
