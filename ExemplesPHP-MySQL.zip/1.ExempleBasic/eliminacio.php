<?php
$db_host="localhost";
$db_user="root";
$db_password="1234";
$db_name="usuaris";
$db_table_name="usuaris";
$db_connection = mysqli_connect($db_host, $db_user, $db_password, $db_name);
if ($db_connection==false) { die('No s\'ha pogut conectar amb la base de dades'); }

$email = $_GET['email'];

$retry_value = mysqli_query($db_connection, "DELETE FROM $db_table_name WHERE Email ='". $email . "';");
if ($retry_value == false) {  die('Error: ' . mysqli_error($db_connection)); }
mysqli_close($db_connection);
header('Location: consulta.php');
?>
