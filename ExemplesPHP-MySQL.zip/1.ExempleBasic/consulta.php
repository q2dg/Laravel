<?php
$db_host="localhost";
$db_user="root";
$db_password="1234";
$db_name="usuaris";
$db_table_name="usuaris";
$db_connection = mysqli_connect($db_host, $db_user, $db_password, $db_name);
if ($db_connection==false) { die('No s\'ha pogut conectar amb la base de dades'); }

$resultat=mysqli_query($db_connection, "SELECT * FROM $db_table_name");

if (mysqli_num_rows($resultat)>0){
	echo "<!DOCTYPE html><head><meta charset='utf-8'><link href='estils.css' rel='stylesheet' type='text/css'></head><body>";
	echo "<table border='1'><thead><tr><td><h3>Nom</h3></td><td><h3>Cognom</h3></td><td><h3>Email</h3></td><td><h3>Eliminar</h3></td></tr></thead><tbody>";
	while($fila= mysqli_fetch_assoc($resultat)){
		//La clau de l'array és el nom que té la columna de la taula a la base de dades
		echo "<tr><td>". $fila["Nom"] ."</td><td>". $fila["Cognom"] . "</td><td>" . $fila["Email"]. "</td>";
		echo "<td><a href='eliminacio.php?email=".$fila["Email"]."'>Eliminar</a></td></tr>";
	}
	echo "</tbody></table><a href='index.html'>Tornar</a></body></html>";
} else {
	echo "<!DOCTYPE html><head><meta charset='utf-8'><link href='estils.css' rel='stylesheet' type='text/css'></head><body>";
	echo "No hi ha cap usuari registrat.<br><a href='index.html'>Tornar</a>";
	echo "</body></html>";
}

mysqli_close($db_connection);
?>
