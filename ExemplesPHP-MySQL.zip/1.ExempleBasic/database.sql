create database usuaris;
use usuaris;
create table usuaris(Email varchar(20) primary key, Nom varchar(20), Cognom varchar(50));

