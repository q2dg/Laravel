<?php
$db_host="localhost";
$db_user="root";
$db_password="1234";
$db_name="usuaris";
$db_table_name="usuaris"; //Aquesta taula tindrà tres camps: "Nom", "Cognom" i "Email", tots tres de tipus varchar. Mirar el fitxer "database.sql" (que es pot usar així: mysql -u root -p1234 < database.sql)
$db_connection = mysqli_connect($db_host, $db_user, $db_password, $db_name);
if ($db_connection==false) { die('No s\'ha pogut conectar amb la base de dades'); }
/*Les línies anteriors es podrien guardar en un fitxer apart per tal de reutilitzar-lo en les diferents pàgines que necessitin
conectar amb el servidor MySQL gràcies a l'ús de les sentències include() i/o require(). */

$name = $_POST['nom'];
$surn = $_POST['cognom'];
$email =$_POST['email'];

$resultat=mysqli_query($db_connection, "SELECT * FROM ".$db_table_name." WHERE Email = '".$email."'");

if (mysqli_num_rows($resultat)>0){
	mysqli_close($db_connection);
	header('Location: fail.html');
} else {
	$retry_value = mysqli_query($db_connection, "INSERT INTO " . $db_table_name ." VALUES ('".$name."','".$surn."','".$email."');");
	if ($retry_value == false) {  die('Error: ' . mysqli_error($db_connection)); }
	mysqli_close($db_connection);
	header('Location: success.html');
}
?>
