<?php
//Inicio sessió (inicialitzant el carro de compra si és el primer cop que sóc en aquesta pàgina) 
session_start();
/*El carro de la compra serà un array associatiu on la clau de cada element serà el codi del producte corresponent (amb això podrem saber el seu nom i el seu preu unitari) i el seu valor la quantitat demanada d'aquest producte (amb això es podrà calcular el preu total d'aquell element i, com a resultat final, el preu total de la compra).*/
if (isset($_SESSION['carrito'])==false){ $_SESSION['carrito']=array(); }
?>
<!DOCTYPE html>
<html>
<head><meta charset="utf8"></head>
<body>
	<form action="articles.php" method="post">
		<select name='tipusproducte'>
			<?php
			//Incloc la definició de la conexió a la base de dades 
			include("conexio.php");
			$conexio= conectarMySQL();
			$resultat = $conexio->query("SELECT * from TIPUSPRODUCTES;");
			while($fila = $resultat->fetch_assoc()) {
   				echo "<option value='". $fila['TIPUS'] ."'>". $fila['TIPUS'] ."</option>";
    			}
			$conexio->close();
			?>
		</select>
		<button type="submit">Veure articles </button>	
	</form>
	<form action="comprar.php" method="post"> 
		<button type="submit">Pagar </button>
	</form>
	<form action="nouclient.html" method="post"> 
		<button type="submit">Fer-se client</button>
	</form>
</body>
</html>
