<?php
session_start();
if (isset($_SESSION['carrito'])==false){ 
	die("Has d'anar a la pàgina <a href='inici.php'>inicial</a> per començar el procés de compra");
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf8">
	<style type="text/css" rel="stylesheet">
		table, td {border: black 1px solid; }
	</style>
</head>
<body>
<h1>Articles escollits</h1>
<?php
include("conexio.php");
$conexio=conectarMySQL();
$resultat=$conexio->query("SELECT * FROM PRODUCTES;");
if($resultat == false) { die("ERROR:". $resultat->error ."Consulta no vàlida"); }

$total=0;
echo "<table>";
while ($fila=$resultat->fetch_assoc()){
	$clau=$fila['CODIPRO'];                           //Per comoditat
	if(array_key_exists($clau,$_SESSION['carrito']) == true){   //Si el producte es troba al carro...
		$quantitat=$_SESSION['carrito'][$clau];   //Per comoditat
		echo "<tr>";
		echo "<td>Nom:". $fila['NOM'] ."</td>";
		echo "<td>Preu unitari:". $fila['PREU'] ."</td>";
		echo "<td>Quantitat:". intval($quantitat) ."</td>";
		echo "<td>Preu:". $fila['PREU']*intval($quantitat) ."</td>";
		$total=$total+ $fila['PREU']*intval($quantitat);
		echo "</tr>";
       	}
}
echo "</table>";
if($total==0) {	die("No ha escollit cap producte encara"); }
else { echo "TOTAL=". $total ."<br>"; }
$conexio->close();
?>
<form action="registrarcompra.php" method="post">
	Email: <input type="email" name="email" required="true">
	<button type="submit">Pagar!</button>
</form>
<a href="inici.php">Seguir comprant</a>
</body>
</html>


