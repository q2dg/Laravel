<?php
function conectarMySQL() {
	$conn = new mysqli("127.0.0.1", "root", "1234", "BOTIGA");
	if ($conn->connect_error) { die("La conexi� ha fallat: ". $conn->connect_error ."<a href='.'>Torna-ho a intentar</a>"); }
	$conn->set_charset("utf8");
	return $conn;
}
?>

