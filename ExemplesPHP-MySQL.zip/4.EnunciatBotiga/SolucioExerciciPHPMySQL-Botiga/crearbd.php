<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
	<h1> Instal·lació de la BD </h1>
	<!-- El valor de l'atribut action indica que les dades seran enviades a la pròpia pàgina actual. Es podria emprar $_SERVER['SCRIPT_NAME'] -->
	<form action="crearbd.php" method="post" ><table>
	   	<tr><td>IP Servidor Mysql:</td><td><input type="text" name="hostname" required="true"></td></tr>
		<tr><td>Usuari Mysql:</td><td><input type="text" name="username" required="true"></td></tr>
		<tr><td>Contrasenya:</td><td><input type="password" name="password" required="true"></td></tr>
		<tr><td colspan="2"><button type="submit">Instalar BD</button></td></tr>
		<input type="hidden" name="shaenviat" value="si">
	</table></form>
<?php
//Aquest tros de codi PHP només s'executarà si el visitant pulsa el botó d'enviar del formulari anterior
if (isset($_POST['shaenviat']) == true) {
	//El fitxer SQL ha d'estar dins de /var/www/html
	$fitxer="botiga.sql";
	//$contingut és una cadena amb tot el contingut del fitxer indicat
	$contingut = file_get_contents($fitxer);
	//A aquesta cadena substitueixo tots els comentaris, ja siguin d'estil C (/*... */) o bé d'una línia (-- ... i/o #...) per salts de línia (\n)
	$patrons_comentaris = array('/\/\*.*(\n)*.*(\*\/)?/', '/\s*--.*\n/', '/\s*#.*\n/');
	$contingut = preg_replace($patrons_comentaris, "\n", $contingut);
	//Creo una nova conexió amb les dades introduïdes al formulari anterior...
	$conn = new mysqli($_POST['hostname'], $_POST['username'], $_POST['password']);
	if ($conn->connect_error > 0) { die("La conexió ha fallat: ". $conn->connect_error ."<a href='.'>Torna-ho a intentar</a>"); }
	//...indico quina codificació utilitzarà aquesta pàgina per enviar les consultes (això és per a què els accents es guardin correctament), i ...
	$conn->set_charset("utf8");
	//...executo totes les consultes en una sola ordre. Cada consulta és distingida de les altres gràcies a la marca ";"
	if ($conn->multi_query($contingut) == true) {
		echo "<br>Totes les consultes SQL s'han executat correctament";
	} else {
		echo "<br>Error: " . $conn->error;
	}
	/*També es podria executar cadascuna de les consultes una rera l'altra, així:
	foreach ($consultes as $consulta) {
	    if (trim($consulta) != '') { //Detecto si la línia no és una línia en blanc
        	echo "Executant la consulta ". $consulta .":";
		if ($conn->query($consulta) == true) {
			echo "<span style='color:green;'>CORRECTE</span>";
		} else {
			echo "<span style='color:red;'>ERROR: " . $conn->error . "</span>";
		}
    	    }	
	}*/
	$conn->close();
}
?> 
</body></html> 
