<?php
include("conexio.php");
session_start(); //Mantinc la sessió per si el visitant ja ha omplert el carro abans d'haver-se registrat

$nom=$_POST['nom'];
$cognom1=$_POST['cognom1'];
$cognom2=$_POST['cognom2'];
$email=$_POST['email'];
$direccio=$_POST['direccio'];
$codipostal=$_POST['codipostal'];
$ciutat=$_POST['ciutat'];
$pais=$_POST['pais'];
$tarjetacredit=$_POST['tarjetacredit'];

$conexio=conectarMySQL();
//Primer miro si l'email ja existeix a la base de dades. Si és així, ho notifico a l'usuari...
$resultat = $conexio->query("SELECT * from CLIENTS where EMAIL='". $email ."';");
if ($resultat == false) { die("Error:". $resultat->error); }  
if ($resultat->num_rows == 1) { die("L'e-mail introduït ja es troba a la base de dades. Pot tornar a intentar-ho clicant <a href='nouclient.html'>aquí</a>"); }
//...si no, el dóno d'alta
$resultat=$conexio->query("INSERT into CLIENTS values(null,'$nom','$cognom1','$cognom2','$email','$direccio','$codipostal','$ciutat','$pais','$tarjetacredit');");
if($resultat == false) { die("ERROR:". $resultat->error() . "Compra no registrada"); }
echo "Moltes gràcies pel seu registre. Pot tornar a la página d'inici clicant <a href='inici.php'>aquí</a>";
$conexio->close();
?>
