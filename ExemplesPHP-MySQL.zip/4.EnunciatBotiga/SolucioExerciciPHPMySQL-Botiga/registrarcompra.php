<?php
session_start();
if (isset($_SESSION['carrito'])==false){ 
	die("Has d'anar a la pàgina <a href='inici.php'>inicial</a> per començar el procés de compra");
}
//Per si no vinc de la pàgina que he de venir...
if (isset($_POST['email'])==false) { die("No s'ha trobat cap mail com l'introduït. Torni a intentar-ho <a href='comprar.php'>aquí</a>"); }
$email=$_POST['email'];
include("conexio.php");
$conexio=conectarMySQL();

$resultat = $conexio->query("SELECT * from CLIENTS where EMAIL='". $email ."';");
$client=$resultat->fetch_row();  //La consulta només trobarà un client perquè he forçat a la BD que l'email sigui únic
if ($resultat == false) { die("Error:". $resultat->error); }
if ($resultat->num_rows == 0 ) { die("No s'ha trobat cap mail com l'introduït. Torni a intentar-ho <a href='comprar.php'>aquí</a>"); }

foreach($_SESSION['carrito'] as $clau => $valor){
	if(empty($valor) == false){
		$insercio= $conexio->query("INSERT INTO COMANDES VALUES (null,'". $client[0] ."', default);");
		if($insercio == false) { die("ERROR: ". $insercio->error ."Insert no vàlid. Compra no guardada."); }
		$idComanda=$conexio->insert_id;
		$insercio= $conexio->query("INSERT INTO DETALLCOMANDES VALUES (". $idComanda .",". $clau .",". $valor .", default);");
		if($insercio == false) { die("ERROR: ". $insercio->error ."Insert no vàlid. Compra no guardada."); }
	}
}
session_unset();
session_destroy();
$conexio->close();
?>
<!DOCTYPE html>
<head><meta charset="utf-8"></head>
<body>
<p> Aviat rebrà la seva compra a casa. Moltes gràcies. Per tornar al principi (buidant el carro), cliqui <a href="inici.php">aquí</a></p>
</body>
</html>
