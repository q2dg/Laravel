<?php
//Continuo la sessió iniciada a inici.php. Si el carro no està inicialitzat (perquè accedeixo a aquesta pàgina directament,p.ex), mostro el missatge adient
session_start();
if (isset($_SESSION['carrito'])==false){ 
	die("Has d'anar a la pàgina <a href='inici.php'>inicial</a> per començar el procés de compra");
} 
$tipusproducte=$_POST['tipusproducte'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf8">
	<style type="text/css" rel="stylesheet">
		table, td {border: black 1px solid; }
	</style>
	<script>
	function actDeact(idCaja){
		if (document.getElementById(idCaja).style.display == "none") {
			document.getElementById(idCaja).style.display ="inline";
		} else {
			document.getElementById(idCaja).style.display ="none";
		}
	}
	</script>
</head>
<body>
<?php
include("conexio.php");
$conexio=conectarMySQL();
$resultat = $conexio->query("SELECT * from PRODUCTES where TIPUS='$tipusproducte';");
if ($resultat == false) { die("Error:". $resultat->error); }
if ($resultat->num_rows == 0 ) { die("No s'ha trobat cap producte del tipus sel.leccionat"); }
echo "<h1> $tipusproducte disponibles </h1>";
echo "<form action='modificarcarro.php' method='post'>";
echo "<input type='hidden' name='tipusproducte' value='$tipusproducte'>"; //A la pàgina modificarcarro.php necessito saber aquesta dada
echo "<table>";
while($fila = $resultat->fetch_assoc()) {
	$idproducte = $fila['CODIPRO'];  //Canvio el nom per comoditat
	echo "<tr>";
	echo "<td>Nom:". $fila['NOM'] ."</td>";
	echo "<td>Preu unitat:". $fila['PREU'] ."</td>";
	/*Aquí la clau està en donar un mateix nom a tots els checkboxs (¡i acabat amb claudàtors!!). 
	Això fa que es pugui treballar amb tots els elements seleccionats com a elements d'un mateix array */
	echo "<td>Seleccionat:<input id='CK". $idproducte ."' type='checkbox' name='seleccio[]' value='". $idproducte ."' onclick=actDeact('QT". $idproducte ."');></td>";
	/*Aquí es torna a fer el mateix truc de donar un nom comú a totes les quantitats desitjades de productes, però ara s'ha hagut d'implementar  		amb Javascript un sistema d'ocultació dinàmica de la caixa de texte corresponent per tal de quadrar el número -i ordre- d'elements de l'array 		'quantprod[]' amb el dels de l'array 'seleccio[]' */
	echo "<td>Quantitat:<input id='QT". $idproducte ."' type='number' name='quantitat[]' min='1' max='99' value='1'></td>";
	//Comprovo si el producte en qüestió ja es trobava seleccionat d'alguna vegada anterior i, si és el cas, ho marco com a tal
	if (array_key_exists($idproducte,$_SESSION['carrito']) == true){
		echo "<script>document.getElementById('CK". $idproducte ."').checked = true;</script>";
		echo "<script>document.getElementById('QT". $idproducte ."').style.display = 'inline';</script>";
		echo "<script>document.getElementById('QT". $idproducte ."').value ='". $_SESSION['carrito'][$idproducte] ."';</script>";
	} else {
		echo "<script>document.getElementById('CK". $idproducte ."').checked = false;</script>";
		echo "<script>document.getElementById('QT". $idproducte ."').style.display = 'none';</script>";
	}
	echo "</tr>";
}
echo "</table>";
$conexio->close();
?>
<button type="submit">Afegir al carro</button></form>
<form action="inici.php"><button type="submit">Tornar sense modificar res</button></form>
</body></html>
