<?php
session_start();
$tipusproducte=$_POST['tipusproducte'];
$seleccio=$_POST['seleccio'];
$quantitat=$_POST['quantitat'];
//Creo un array associatiu amb el codi dels productes seleccionats a la p�gina anterior com a clau i la seva quantitat com a valor (�s la mateixa estructura que volem pel carro)
for ($i=0; $i<count($seleccio); $i++){
	$falsCarrito[$seleccio[$i]] = $quantitat[$i];
}
include("conexio.php");
$conexio=conectarMySQL();
$resultat=$conexio->query("SELECT CODIPRO from PRODUCTES where TIPUS='$tipusproducte';");
if ($resultat == false) { die("Error:". $resultat->error); }
while ($fila=$resultat->fetch_assoc()) {                           //Repaso cada producte del tipus tractat a veure si cal modificar el carro
	$clau= $fila['CODIPRO'];				   //Canvio la notaci� per comoditat
	$estaaSeleccio= array_key_exists($clau,$falsCarrito);      //Busco el producte dins la selecci� feta a la p�gina anterior
	$estaaCarro= array_key_exists($clau,$_SESSION['carrito']); //Busco el producte dins el carro
	//Si el producte est� en la selecci� per� no est� encara dins el carro, l'afegeixo
	if($estaaSeleccio == true && $estaaCarro == false) {
		$_SESSION['carrito'][$clau]=$falsCarrito[$clau]; 
	}
	//Si el producte no est� en la selecci� per� s� est� encara dins el carro, el trec
	if($estaaSeleccio == false && $estaaCarro == true) { 
		unset($_SESSION['carrito'][$clau]);		
	}
	//Encara que el producte estigui a la selecci� i tamb� al carro, �s possible que calgui actualitzar la quantitat demanada
	if($estaaSeleccio == true && $estaaCarro == true) { 
		if ($_SESSION['carrito'][$clau] != $falsCarrito[$clau]) { 
			$_SESSION['carrito'][$clau] = $falsCarrito[$clau];
		}
	}
}
$conexio->close();
header("Location:inici.php");  
?>


