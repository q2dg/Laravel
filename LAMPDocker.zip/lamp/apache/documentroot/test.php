<?php
$servername = "db";
$username = "root";
$password = "1234";
$db = "test_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connectat!";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 
